/* particlesJS.load(@dom-id, @path-json, @callback (optional)); */
particlesJS.load('particles-js', 'assets/json/particulas.json', function () {
    console.log('callback - particles.js config loaded');
});