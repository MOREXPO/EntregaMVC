Iago Moreda Expósito(15492131K), Selene Carnero Cid(44664013Z), Pedro Jalda Fonseca(53614526P)

El proyecto esta levantado con docker, el cual en el archivo Makefile tienes comandos para desplegar los contenedores de manera mas comoda(utiliza "make deploy-dev" para levantar el proyecto en desarrollo).

Ademas tienes el proyecto en este repositorio de git https://github.com/MOREXPO/IAmOn